package br.com.cev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComprasEVendasApplicationTests {

	@Test
	void contextLoads() {
	}

}
